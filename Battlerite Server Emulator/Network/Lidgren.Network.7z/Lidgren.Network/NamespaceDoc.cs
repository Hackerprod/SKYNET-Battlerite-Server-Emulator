namespace Lidgren.Network
{
	internal class NamespaceDoc
	{
	}
}
