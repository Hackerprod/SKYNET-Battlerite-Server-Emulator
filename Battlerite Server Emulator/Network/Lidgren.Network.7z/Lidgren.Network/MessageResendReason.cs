namespace Lidgren.Network
{
	internal enum MessageResendReason
	{
		Delay,
		HoleInSequence
	}
}
