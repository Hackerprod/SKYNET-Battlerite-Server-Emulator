namespace Lidgren.Network
{
	public enum NetPeerStatus
	{
		NotRunning,
		Starting,
		Running,
		ShutdownRequested
	}
}
