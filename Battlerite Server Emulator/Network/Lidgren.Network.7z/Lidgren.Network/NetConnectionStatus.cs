namespace Lidgren
{
	public enum NetConnectionStatus2
	{
		None,
		InitiatedConnect,
		RespondedConnect,
		Connected,
		Disconnecting,
		Disconnected
	}
}
