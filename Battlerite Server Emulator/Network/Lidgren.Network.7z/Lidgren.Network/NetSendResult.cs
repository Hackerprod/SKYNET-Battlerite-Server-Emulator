namespace Lidgren.Network
{
	public enum NetSendResult
	{
		Failed,
		Sent,
		Queued,
		Dropped
	}
}
